﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CWStockOnHand.WebReference;

namespace WindowsFormsApp1
{
    public partial class frmSOH : Form
    {
        public frmSOH()
        {
            InitializeComponent();
        }


        
        private void button1_Click(object sender, EventArgs e)
        {
            lblResult.Text = "";
            DataSet g_ds = new DataSet(); 
            WebServiceMgt ws3 = new WebServiceMgt
            {
                UseDefaultCredentials = true,

                Url = "http://210.215.73.249:7057/CWUAT_NAV2017/WS/Countrywide%20Live%20Phase2/Codeunit/WebServiceMgt"
            };

          
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string xmlFilePath = openFileDialog.FileName;
                using (DataSet ds = new DataSet())
                {
                    ds.ReadXml(xmlFilePath);
                    dg1.DataSource = ds.Tables[0];
                    g_ds = ds;
                }
            }
         
               

                
                SOH_Report1 sOH_Report1 = new SOH_Report1();
               
                List<SOH_Line1> sohList = new List<SOH_Line1>();
                for (int i = 0; i <g_ds.Tables[0].Rows.Count ; i++)
                {

                SOH_Line1 sOH_Line1 = new SOH_Line1();
                sOH_Line1.MemberId = dg1.Rows[i].Cells["MemberID"].Value.ToString();                                 
                    sOH_Line1.ContractCode = dg1.Rows[i].Cells["ContractCode"].Value.ToString();
                    sOH_Line1.DocumentType = dg1.Rows[i].Cells["DocumentType"].Value.ToString(); 
                    sOH_Line1.DocumentNo = dg1.Rows[i].Cells["DocumentNo"].Value.ToString();
                    sOH_Line1.LineNo = Convert.ToInt32(dg1.Rows[i].Cells["LineNo"].Value);
                    sOH_Line1.Date = dg1.Rows[i].Cells["Date"].Value.ToString();
                    sOH_Line1.ItemNo = dg1.Rows[i].Cells["ItemNo"].Value.ToString(); 
                    sOH_Line1.SalesUOM = dg1.Rows[i].Cells["SalesUOM"].Value.ToString(); 
                    sOH_Line1.ETADeliveryDate = dg1.Rows[i].Cells["ETADeliveryDate"].Value.ToString();
                    sOH_Line1.StockOnHandQuantity = dg1.Rows[i].Cells["StockOnHandQuantity"].Value.ToString(); 
                    sOH_Line1.StockOnOrderQuantity = dg1.Rows[i].Cells["StockOnOrderQuantity"].Value.ToString();
                    sOH_Line1.Comments = dg1.Rows[i].Cells["Comments"].Value.ToString();
                    sohList.Add(sOH_Line1);

                }


               
               
               
                sOH_Report1.SOH_Line = sohList.ToArray();


                SOH_Report2 sOH_Report2 = new SOH_Report2();
            try
            {

                ws3.StockOnHand(sOH_Report1, ref sOH_Report2);


                dg2.Columns.Clear();
                dg2.Columns.Add("Status", "Status");
                dg2.Columns.Add("SystemDateTime", "System Date Time");
                dg2.Columns.Add("MemberID", "Member ID");
                dg2.Columns.Add("ContractCode", "Contract Code");
                dg2.Columns.Add("DocumentType", "Document Type");
                dg2.Columns.Add("DocumentNo", "Document No");
                dg2.Columns.Add("LineNo", "Line No");
                dg2.Columns.Add("Date", "Date");
                dg2.Columns.Add("ItemNo", "Item No");
                dg2.Columns.Add("SalesUOM", "Sales UOM");
                dg2.Columns.Add("ETADeliveryDate", "ETA Delivery Date");
                dg2.Columns.Add("StockOnHandQuantity", "Stock On Hand Quantity");
                dg2.Columns.Add("StockOnOrderQuantity", "Stock On Order Quantity");
                dg2.Rows.Clear();
                foreach (var sOH_line2 in sOH_Report2.SOH_Line )
                {

        

                    dg2.Rows.Add(
                            sOH_line2.Status,
                            sOH_line2.SystemDateTime,
                            sOH_line2.MemberId,
                            sOH_line2.ContractCode,
                            sOH_line2.DocumentType,
                            sOH_line2.DocumentNo,
                            sOH_line2.LineNo,
                            sOH_line2.Date,
                            sOH_line2.ItemNo,
                            sOH_line2.SalesUOM,
                            sOH_line2.ETADeliveryDate,
                            sOH_line2.StockOnHandQuantity,
                            sOH_line2.StockOnOrderQuantity
                           );
                    
                }

            }

            catch (Exception ex)
            {

                lblResult.Text = ex.Message;

            }


        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        static public string EncodeTo64(string toEncode)

        {

            byte[] toEncodeAsBytes

                  = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);

            string returnValue

                  = System.Convert.ToBase64String(toEncodeAsBytes);

            return returnValue;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblResult.Text = "";
            string result = "";
            WebServiceMgt ws3 = new WebServiceMgt
            {
                UseDefaultCredentials = true,

                Url = "http://210.215.73.249:7057/CWUAT_NAV2017/WS/Countrywide%20Live%20Phase2/Codeunit/WebServiceMgt"
            };

           
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string xmlFilePath = openFileDialog.FileName;
                using (DataSet ds = new DataSet())
                {
                    ds.ReadXml(xmlFilePath);
                    dg1.DataSource = ds.Tables[0];
                    StringWriter sw = new StringWriter();
                    ds.WriteXml(sw);
                    result = sw.ToString();
                    
                }
            }



           

            SOH_Report2 sOH_Report2 = new SOH_Report2();
            try
            {

                

                ws3.GetStockOnHand(EncodeTo64(result), ref sOH_Report2);



                dg2.Columns.Add("Status", "Status");
                dg2.Columns.Add("SystemDateTime", "System Date Time");
                dg2.Columns.Add("MemberID", "Member ID");
                dg2.Columns.Add("ContractCode", "Contract Code");
                dg2.Columns.Add("DocumentType", "Document Type");
                dg2.Columns.Add("DocumentNo", "Document No");
                dg2.Columns.Add("LineNo", "Line No");
                dg2.Columns.Add("Date", "Date");
                dg2.Columns.Add("ItemNo", "Item No");
                dg2.Columns.Add("SalesUOM", "Sales UOM");
                dg2.Columns.Add("ETADeliveryDate", "ETA Delivery Date");
                dg2.Columns.Add("StockOnHandQuantity", "Stock On Hand Quantity");
                dg2.Columns.Add("StockOnOrderQuantity", "Stock On Order Quantity");
      
                
               
             
                dg2.Rows.Clear();
                foreach (var sOH_line2 in sOH_Report2.SOH_Line)
                {


                    

                    dg2.Rows.Add(
                        sOH_line2.Status,
                        sOH_line2.SystemDateTime,
                        sOH_line2.MemberId, 
                        sOH_line2.ContractCode,
                        sOH_line2.DocumentType,
                        sOH_line2.DocumentNo,
                        sOH_line2.LineNo, 
                        sOH_line2.Date,
                        sOH_line2.ItemNo, 
                        sOH_line2.SalesUOM, 
                        sOH_line2.ETADeliveryDate,
                        sOH_line2.StockOnHandQuantity,
                        sOH_line2.StockOnOrderQuantity
                       );

                }

            }

            catch (Exception ex)
            {

                lblResult.Text = ex.Message;

            }

        }

        private void dg2_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            foreach (DataGridViewRow Myrow in dg2.Rows)
            {            
                if (Convert.ToString(Myrow.Cells[0].Value)=="Error") 
                {
                   
                    Myrow.Cells[0].Style.ForeColor = Color.Red;
                }
                else
                {
                    Myrow.Cells[0].Style.ForeColor = Color.Green;
                }
            }
        }

        private void dg2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
